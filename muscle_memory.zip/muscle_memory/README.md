# Muscle Memory – Remember what matters.
## Build the APK with GitHub (no PC tools needed)
1. Create a new GitHub repo and upload ALL files from this folder, including the hidden `.github/workflows/build.yml`.
2. Open the repo > Actions tab > "Build APK" (it runs on every push; or press Run workflow).
3. When it turns green, open the run > Artifacts > download `muscle-memory-debug-apk`, unzip it, and install app-debug.apk on your phone (allow "install unknown apps").
4. Open the app and tap Settings > Grant permissions. Set battery usage to Unrestricted.
The workflow generates the Android scaffold with `flutter create`, applies the manifest + desugaring patch, makes icons from assets/icon.png, and builds.
